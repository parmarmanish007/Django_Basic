num = int(input("enter number : "))
if num %2==0:
    print("number is even")
else:
    print("number is odd")