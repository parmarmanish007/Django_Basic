num=int(input("enter a number:"))
if num<10:
    num=num**2
    print("square of num",num)
else:
    print("num is gretaerthan 10")
