num1=int(input("enter first number :"))
num2=int(input("enter second number :"))
if num1<num2:
    print("num1 is smallest")
else:
    print("num2 is smallest")