num1=int(input("enter first number :"))
num2=int(input("enter second number :"))

temp=num1
num1=num2
num2=temp
print("num1 after swapping",num1)
print("num2 after swapping",num2)
