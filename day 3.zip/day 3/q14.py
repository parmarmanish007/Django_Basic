num1=int(input("enter a first number:"))
num2=int(input("enter a second number:"))

num1,num2=num2,num1

print("after swaping num1 is",num1)
print("after swaping num2 is",num2)
