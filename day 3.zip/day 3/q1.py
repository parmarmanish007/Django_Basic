nums1= int(input("enter first number :"))
nums2= int(input("enter second number :"))
nums3= int(input("enter third number :"))
nums4= int(input("enter four number :"))
nums5= int(input("enter five number :"))

avg=nums1+nums2+nums3+nums4+nums5/5

print("avg of number : ",avg)


