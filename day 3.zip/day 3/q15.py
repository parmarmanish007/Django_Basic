num1=int(input("enter a starting number :"))
num2=int(input("enter a ending number : "))

for i in range(num1,num2,-3):
    print(i)
