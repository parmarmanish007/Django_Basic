num=int(input("enter a number : "))
if num ==0:
    print("number is Zero ")
elif num<0:
    print("number is negative")
elif num>0:
    print("number is positive")