num=int(input("enter a number :"))
if num>=0:
    if num==0:
        print("num is zero")
    else:
        print("num is positive")
else:
    print("num is negative")