from django.shortcuts import render

# Create your views here.
def form(request):
    return render(request,'form.html')

def formprocess(request):
    a=request.POST['txt1']
    b=request.POST['txt2']
    c=request.POST['txt3']
    d=request.POST['txt4']
    e=request.POST['txt5']
    f=request.POST['txt6']
    g=request.POST['txt7']

    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
    print(f)
    print(g)

    return render(request,'detalis.html',{'mya':a,'myb':b,'myc':c,'myd':d,'mye':e,'myf':f,'myg':g})