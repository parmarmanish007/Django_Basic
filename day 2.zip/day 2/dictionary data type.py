d = {1:'parmar',2:'manish','key':10}
print(type(d))
print("d[1]= ",d[1])
print("d[2]= ",d[2])
print("d['key']= ",d['key'])