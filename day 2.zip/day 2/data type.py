n1 = 50
print(n1)
print(type(n1))

n2 = 50.5
print(n2)
print(type(n2))

n3 = 3 + 2j
print(n3)
print(type(n3))
print(id(n3))

