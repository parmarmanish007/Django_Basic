print("Hello World")
# Variable store
a = 10
b = 20
c = "Manish"
name = "manish"
print("Name is",name)
#assiging multiple
a, b, c = 10,24,"manish"
print(a)
print(b)
print(c)
a, b, c = 10,24,"manish"
print("value is : ",a)
print("value is : ",b)
print("value is : ",c)