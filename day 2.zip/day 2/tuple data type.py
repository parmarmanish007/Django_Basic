tuple = (10,20,30,40,"manish")
print(tuple)
print("tuple[2]=",tuple[2])
print("tuple[0:3]=",tuple[0:3])
print("tuple[2:]=",tuple[2:])
print("tuple[:3]=",tuple[:3])


