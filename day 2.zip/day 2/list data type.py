list = [10,20,30,40,"manish"]
print(list)
print("list[2]=",list[2])
print("list[0:3]=",list[0:3])
print("list[5:]=",list[5:])