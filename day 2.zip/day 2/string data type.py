name = "Parmar manish"
print("Name is",name)
print(name[0])
print(name[2:5])
print(name[2:])
print(name[:3])
print(name*3)
print(name + " jagdishbhai")