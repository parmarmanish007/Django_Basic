#arithmatic oparator
x = 50
y = 30
print("x + y=",x + y)

print("x - y=",x - y)

print("x * y=",x * y)

print("x / y=",x / y)

print("x // y=",x // y)

print("x ** y=",x ** y)