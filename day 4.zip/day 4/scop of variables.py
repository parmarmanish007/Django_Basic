#scope of variable
def disp():
    x = 10
    print("value inside funaction",x)

x = 20
disp()
print("value outside funaction", x)

    