#is,is not
x=20
y=20

print(x is y)
print(x is not y)