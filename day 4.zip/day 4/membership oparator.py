# in,in not
x=20
y=11
list=[10,20,11,50,30]
print(x in list)
print(y in list)
print(y not in list)