#demo file scratch file
import scratch
name = scratch.disp("manish")
print(name)