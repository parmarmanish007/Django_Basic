def disp(name):
   return name