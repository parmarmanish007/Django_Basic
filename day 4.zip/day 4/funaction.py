#funaction
def show():
    print("manish")
show()
show()

def disp(name):
    print("Name is: ",name)
disp("parmar manish")
