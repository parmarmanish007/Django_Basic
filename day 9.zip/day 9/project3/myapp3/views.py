from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request,'home.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def myform(request):
    return render(request,'myform.html')

def process(request):
    print('well come')
    print(request.method)
    print(request.POST)
    a = int(request.POST['tax1'])
    b = int(request.POST['tax2'])
    c = a + b
    print(c)
    return render(request,'ans.html',{'mya':a,'myb':b,'mysum':c})