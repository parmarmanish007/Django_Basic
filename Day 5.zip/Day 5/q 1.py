class cal1():
    def setdata(self):
        self.n1=10
        self.n2=20
        self.n3=30
    def display(self):
        ans = self.n1 +self.n2 +self.n3
        print("Ans is ",ans)

c=cal1()
c.setdata()
c.display() 