from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return HttpResponse('well come to home page')

def about(request):
    return HttpResponse('well come to about page')

def contact(request):
    return HttpResponse('well come to contact page')
